package com.javafile.dao;
import java.sql.*;
public class DB {

	static Connection con;
	
	public static Connection getCon(){
		try {
			// load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			// create the connection.....
			String user="root";
			String password="root123";
			String url="jdbc:mysql://localhost:3306/fees";
			
			con=DriverManager.getConnection(url, user, password);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return con;
		
	}

}
